<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Active Cattle Detection and Counting System</title>
    <link rel="stylesheet" href="css/web.css">
    <link rel="stylesheet" href="css/background.css">
</head>
<body>
    <h1 class="h1">
        BACKGROUND
   </h1>
        <div class="obj">
            
            <nav class="object">
                <p>The cattle farming industry is a major business that supplies the world with dairy, beef and leather.
                    Keeping an inventory of cattle in real-time is important because this information will allow farmers to
                    get an immediate alert if any animal goes missing. Also, keeping track of the movement of the cattle will
                    give information on their status.<br>
                    This project requires the student to design and develop a system that can count cattle in real time and
                    give information on their movements.</p>
            </nav>
        </div>
   


       
    
   
</body> 
</html>