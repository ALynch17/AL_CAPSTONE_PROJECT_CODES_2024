<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Modify this part according to your ESP32 IP address and endpoint
    $esp32_ip = "192.168.68.60"; // Example IP address
    $esp32_port = 80; // Example endpoint on ESP32
    
    // User input data from the form
    $latitude1 = $_POST["latitude1"];
    $longitude1 = $_POST["longitude1"];
    
    // Prepare data to send to ESP32
    $data = "lat1=$lat1&long1=$long1";
    // Convert the data array to JSON format
$json_data = json_encode($data);

// Create a cURL handle to send the POST request
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "http://$esp32_ip:$esp32_port");
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $json_data);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

// Execute the cURL request and capture the response
$response = curl_exec($ch);

// Check if the request was successful
if ($response === false) {
    echo 'Error sending data to ESP32: ' . curl_error($ch);
} else {
    echo 'Data sent successfully to ESP32';
}


// Close the cURL handle
curl_close($ch);
}
?>
