<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/PHPMailer/src/Exception.php';
require 'PHPMailer/PHPMailer/src/PHPMailer.php';
require 'PHPMailer/PHPMailer/src/SMTP.php';

$mail = new PHPMailer(true);
//$mail->SMTPDebug = SMTP::DEBUG_SERVER; // Enable debugging output

// Your SMTP configuration and email sending code here...
$mail->isSMTP();
$mail->Host = 'smtp.gmail.com'; // Replace with your SMTP server hostname
$mail->SMTPAuth = true;
$mail->Username = 'capstonelynch@gmail.com'; // Replace with your SMTP username
$mail->Password = 'ldrdxbboomlshihy'; // Replace with your SMTP password 
$mail->SMTPSecure = 'ssl'; // Use 'ssl' for SSL encryption
$mail->Port = 465; // Port number for SSL (usually 465)

$mail->setFrom('capstonelynch@gmail.com', 'Your Name');
$mail->addAddress('alex.lynch1906@gmail.com', 'Recipient Name');
$mail->Subject = 'Test Email';
$mail->Body = 'This is a test email.';
$mail->SMTPOptions = array(
    'ssl' => array(
        'verify_peer' => false,
        'verify_peer_name' => false,
        'allow_self_signed' => true
    )
);

if ($mail->send()) {
    echo 'Email sent successfully.';
} else {
    echo 'Failed to send email: ' . $mail->ErrorInfo;
}

?>