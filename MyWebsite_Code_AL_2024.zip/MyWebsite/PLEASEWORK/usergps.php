<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Input Form</title>
</head>
<body>
    <h2>Enter Coordinates</h2>
    <form method="post" action="sendtoesp.php">
        <input type="text" name="latitude1" placeholder="latitude1"><br><br>
        <input type="text" name="longitude1" placeholder="longitude1"><br><br>
        <input type="submit" value="Submit">
    </form>
</body>
</html>
