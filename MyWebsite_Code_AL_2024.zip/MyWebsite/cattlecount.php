<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Active Cattle Detection and Counting System</title>
    <link rel="stylesheet" href="css/web.css">
    <link rel="stylesheet" href="css/cattlecount.css">
</head>
<body>
    <h1 class="h1">
        NUMBER OF CATTLE
   </h1>
        <div class="obj">
            
            <nav class="object">
            <p>
            <?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "capdatabase";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL query to count total number of rows
$sql_total_rows = "SELECT COUNT(*) AS total FROM cattle";
$result_total = $conn->query($sql_total_rows);

if ($result_total->num_rows > 0) {
    // Fetch the result
    $row_total = $result_total->fetch_assoc();
    $total_rows = $row_total['total'];
    echo "Total cows registered with the farm: " . $total_rows . "<br>";
} else {
    echo "Error retrieving total row count: " . $conn->error;
}

// SQL query to count number of rows with "INSIDE" in the inside_or_outside column
$sql_inside_rows = "SELECT COUNT(*) AS inside FROM cattle WHERE inside_or_outside = 'INSIDE'";
$result_inside = $conn->query($sql_inside_rows);

if ($result_inside->num_rows > 0) {
    // Fetch the result
    $row_inside = $result_inside->fetch_assoc();
    $inside_rows = $row_inside['inside'];
    echo "Number of cows inside the farm: " . $inside_rows;
} else {
    echo "Error retrieving 'INSIDE' row count: " . $conn->error;
}

// Close the connection
$conn->close();
?>

               </p>
            </nav>
        </div>
   


       
    
   
</body>
</html>