<?php

declare(strict_types=1);

function is_input_empty(string $username, string $pword){

    if (empty($username)||empty($pword)){
        return true;
    }
    else{
        return false;
    }
}

function is_username_wrong(bool|array $result){

    if (!$result){
        return true;
    }
    else{
        return false;
    }
}

function is_pword_wrong(bool|array $result2){

    if (!$result2){
        return true;
    }
    else{
        return false;
    }
}
/*
function is_pword_wrong(string $pword, string $hPword){

    if (!password_verify($pword,$hPword)){
        return true;
    }
    else{
        return false;
    }
}*/
