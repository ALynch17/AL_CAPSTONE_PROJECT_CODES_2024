<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/PHPMailer/src/Exception.php';
require 'PHPMailer/PHPMailer/src/PHPMailer.php';
require 'PHPMailer/PHPMailer/src/SMTP.php';

// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$database = "capdatabase";


// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to send email using PHPMailer
function sendEmail($to, $tofname,$tolname, $subject, $message) {
    $mail = new PHPMailer(true);
    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com'; // Set the SMTP server to send through
        $mail->SMTPAuth   = true;
        $mail->Username   = 'capstonelynch@gmail.com'; // SMTP username
        $mail->Password   = 'ldrdxbboomlshihy'; // SMTP password
        $mail->SMTPSecure = 'ssl';
        $mail->Port       = 465;

        // Recipients
        $mail->setFrom('capstonelynch@gmail.com', 'Capstone Lynch');
        $mail->addAddress($to, $tofname,$tolname);

        // Content
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body    = $message;
        $mail->SMTPOptions = array(
            'ssl' => array(
                'verify_peer' => false,
                'verify_peer_name' => false,
                'allow_self_signed' => true
            )
        );
        $mail->send();
        echo "Message has been sent to $tofname $tolname <$to>\n";
    } catch (Exception $e) {
        echo "Message could not be sent to $tofname $tolname <$to>. Mailer Error: {$mail->ErrorInfo}\n";
    }
}

// Function to get all user emails and names
function getUserEmailsAndNames($conn) {
    $users = [];
    $result = $conn->query("SELECT firstname, lastname, email FROM users");
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $users[] = $row;
        }
    }
    return $users;
}

// Function to check cattle conditions and send alerts
function checkCattleConditionsAndSendAlerts($conn) {
    $users = getUserEmailsAndNames($conn);
    if (empty($users)) {
        return;
    }
    $result = $conn->query("SELECT * FROM cattle");
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $alerts = [];
            $cowId = $row['id'];
          
                       // if ($CowId == 4){
            if ($row['battery_status'] < 20) {
                $alerts[] = "Cow ID: $cowId - Battery status is less than 20% (Current: {$row['battery_status']}%).";
            }
            $lastMovedTime = new DateTime($row['last_time_moved']);
            $currentTime = new DateTime();
            $timeDiff = $currentTime->diff($lastMovedTime);
            if ($timeDiff->i >= 2 && $row['mstate'] == 0) { // Check if mstate is 0 for 2 minutes
                $alerts[] = "<br><br>Cow ID: $cowId - The cow has not moved for 2 minutes (Last movement: {$row['last_time_moved']}).<br><br>";
            }
            
            if ($row['inside_or_outside'] === 'OUTSIDE') {
                $alerts[] = "<br><br>Cow ID: $cowId - The cow has moved outside the farm (Last time inside: {$row['last_time_inside']}).<br><br>";
            }

            $lastchangedtime = new DateTime($row['last_changed']);
            $currentTime = new DateTime();
            $timeDiff = $currentTime->diff($lastchangedtime);
            if ($timeDiff->i >= 2 && $row['onoff'] == 0) { // Check if mstate is 0 for 2 minutes
                $alerts[] = "<br><br>Cow ID: $cowId - The cow etag has been offline for 2 minutes (Last online: {$row['last_changed']}).<br><br>";
            }

       // }
       if ($row['AUTHORIZED'] !=1){
            if (!empty($alerts)) {
                $subject = "Cattle Alert";
                $message = implode(" ", $alerts);
                foreach ($users as $user) {
                    sendEmail($user['email'], $user['firstname'], $user['lastname'], $subject, $message);
                }
            }
        }
    }

    }
}

// Run the check every 30 seconds
while (true) {
    checkCattleConditionsAndSendAlerts($conn);
    sleep(60); // Sleep for 30 seconds
}

// Close connection
$conn->close();
?>
