
<?php

//use PHPMailer\PHPMailer\PHPMailer;
//use PHPMailer\PHPMailer\Exception;

// Include PHPMailer files and any necessary configurations
//require 'phpmailer/src/Exception.php';
//require 'phpmailer/src/PHPMailer.php';
//require 'phpmailer/src/SMTP.php'; 
//require 'testemail.php';

$servername = "localhost"; // Change to your server name
$username = "root"; // Change to your MySQL username
$password = ""; // Change to your MySQL password
$dbname = "capdatabase"; // Change to your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['lat1']) && isset($_POST['long1']) && isset($_POST['lat2']) && isset($_POST['long2'])&& isset($_POST['lat3']) && isset($_POST['long3'])&& isset($_POST['lat4']) && isset($_POST['long4'])) {
    $lat1 = $_POST['lat1'];
    $long1 = $_POST['long1'];
    $lat2 = $_POST['lat2'];
    $long2 = $_POST['long2'];
    $lat3 = $_POST['lat3'];
    $long3 = $_POST['long3'];
    $lat4 = $_POST['lat4'];
    $long4 = $_POST['long4'];
    // Repeat for other variables

// Assume form data is submitted via POST method
$latitudes = array($lat1,$lat2,$lat3,$lat4);
$longitudes = array($long1,$long2,$long3,$long4);

// Check if the coordinates table is empty
$result = $conn->query("SELECT COUNT(*) as count FROM coordinates");
$row = $result->fetch_assoc();
$table_empty = ($row['count'] == 0);

// Store or update coordinates in the coordinates table
if ($table_empty) {
    $stmt = $conn->prepare("INSERT INTO coordinates (latitude1, longitude1, latitude2, longitude2, latitude3, longitude3, latitude4, longitude4) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
} else {
    $stmt = $conn->prepare("UPDATE coordinates SET latitude1 = ?, longitude1 = ?, latitude2 = ?, longitude2 = ?, latitude3 = ?, longitude3 = ?, latitude4 = ?, longitude4 = ? WHERE id = 1"); // Assuming id = 1 for the single row
}
$stmt->bind_param("dddddddd", $lat1, $long1, $lat2, $long2, $lat3, $long3, $lat4, $long4);

$lat1 = $latitudes[0];
$long1 = $longitudes[0];
$lat2 = $latitudes[1];
$long2 = $longitudes[1];
$lat3 = $latitudes[2];
$long3 = $longitudes[2];
$lat4 = $latitudes[3];
$long4 = $longitudes[3];

$stmt->execute();
$stmt->close();

echo "Coordinates stored/updated.";
} else {
    echo "No Coordinates received.";
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['authorize'])) {
    $authorize = $_POST['authorize'];
    if ($authorize == '1' || $authorize == '0') {
        $stmt = $conn->prepare("UPDATE cattle SET AUTHORIZED = ? WHERE id = 4");
        $stmt->bind_param("i", $authorize);
        if ($stmt->execute()) {
            echo 'Email status for Cow 4 updated successfully.';
        } else {
            echo 'Failed to update email status for Cow 4.';
        }
        $stmt->close();
    } else {
        echo 'Invalid status value.';
    }
} else {
    echo 'Invalid request.';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['offon'])) {
    $offon = $_POST['offon'];
    if ($offon == '1' || $offon == '0') {
        $stmt = $conn->prepare("UPDATE cattle SET onoff = ? WHERE id = 4"); // Assuming the cow ID is 4
        $stmt->bind_param("i", $offon);
        if ($stmt->execute()) {
            echo 'On/Off status updated successfully.';
        } else {
            echo 'Failed to update On/Off status.';
        }
        $stmt->close();
    } else {
        echo 'Invalid On/Off value.';
    }
} else {
    echo 'Invalid request.';
}

// Check if the POST request contains the data
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["latitude"]) && isset($_POST["longitude"]) && isset($_POST["mstate"]) && isset($_POST["battery_status"]) && isset($_POST["onoff"])) {
    $latitude = $_POST["latitude"];
    $longitude = $_POST["longitude"];
    $mstate = $_POST["mstate"];
    $battery_status=$_POST["battery_status"];
    $onoff=$_POST["onoff"];

// SQL query to select all rows from coordinates table
$sql = "SELECT * FROM coordinates";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Initialize variables for min/max latitude and longitude
    $min_lat = PHP_INT_MAX;
    $max_lat = PHP_INT_MIN;
    $min_long = PHP_INT_MAX;
    $max_long = PHP_INT_MIN;

    // Loop through each row in the result set
    while ($row = $result->fetch_assoc()) {
        // Get latitude and longitude values from the current row
        $latitude1 = $row['latitude1'];
        $longitude1 = $row['longitude1'];
        $latitude2 = $row['latitude2'];
        $longitude2 = $row['longitude2'];
        $latitude3 = $row['latitude3'];
        $longitude3 = $row['longitude3'];
        $latitude4 = $row['latitude4'];
        $longitude4 = $row['longitude4'];

        // Update min/max latitude and longitude values
        $min_lat = min($min_lat, $latitude1, $latitude2, $latitude3, $latitude4);
        $max_lat = max($max_lat, $latitude1, $latitude2, $latitude3, $latitude4);
        $min_long = min($min_long, $longitude1, $longitude2, $longitude3, $longitude4);
        $max_long = max($max_long, $longitude1, $longitude2, $longitude3, $longitude4);
    }

    if ($latitude > $min_lat && $latitude < $max_lat && $longitude > $min_long && $longitude < $max_long) {
//return true; // Inside the quadrilateral
$inside_or_outside="INSIDE";
$check=1;
} else {
//return false; // Outside the quadrilateral
$inside_or_outside="OUTSIDE";
$check=0;
}
// Check if mstate is 1 (moving)

$sql = "SELECT * FROM cattle";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $last_time_moved=$row['last_time_moved'];
        $last_time_inside=$row['last_time_inside'];
        $last_changed=$row['last_changed'];
    }
}

if ($mstate == 1) {
    $current_time = date('Y-m-d H:i:s'); // Current time
    $six_hours_earlier = date('Y-m-d H:i:s', strtotime('-7 hours', strtotime($current_time)));
    $sql = "UPDATE cattle SET mstate='$mstate', latitude='$latitude', longitude='$longitude', inside_or_outside='$inside_or_outside', last_time_moved='$six_hours_earlier', battery_status='$battery_status',last_time_inside='$last_time_inside', onoff='$onoff', last_changed='$last_changed' WHERE id=4";
    $lasttime=$six_hours_earlier;
} else {
    $sql = "UPDATE cattle SET mstate='$mstate', latitude='$latitude', longitude='$longitude', inside_or_outside='$inside_or_outside', last_time_moved='$last_time_moved', battery_status='$battery_status',last_time_inside='$last_time_inside', onoff='$onoff', last_changed='$last_changed' WHERE id=4";
    $lasttime=$last_time_moved;
}

if ($inside_or_outside == "INSIDE") {
    $current_time = date('Y-m-d H:i:s'); // Current time
    $six_hours_earlier = date('Y-m-d H:i:s', strtotime('-7 hours', strtotime($current_time)));
    $sql = "UPDATE cattle SET mstate='$mstate', latitude='$latitude', longitude='$longitude', inside_or_outside='$inside_or_outside', last_time_moved='$lasttime', battery_status='$battery_status',last_time_inside='$six_hours_earlier', onoff='$onoff', last_changed='$last_changed' WHERE id=4";
    $lastinside=$six_hours_earlier;
} else {
    $sql = "UPDATE cattle SET mstate='$mstate', latitude='$latitude', longitude='$longitude', inside_or_outside='$inside_or_outside', last_time_moved='$lasttime', battery_status='$battery_status',last_time_inside='$last_time_inside', onoff='$onoff', last_changed='$last_changed' WHERE id=4";
    $lastinside=$last_time_inside;
}   

if ($onoff == 1) {
    $current_time = date('Y-m-d H:i:s'); // Current time
    $six_hours_earlier = date('Y-m-d H:i:s', strtotime('-7 hours', strtotime($current_time)));
    $sql = "UPDATE cattle SET mstate='$mstate', latitude='$latitude', longitude='$longitude', inside_or_outside='$inside_or_outside', last_time_moved='$lasttime', battery_status='$battery_status',last_time_inside='$lastinside', onoff='$onoff', last_changed='$six_hours_earlier' WHERE id=4";
    //$lasttime=$current_time;
} else {
    $sql = "UPDATE cattle SET mstate='$mstate', latitude='$latitude', longitude='$longitude', inside_or_outside='$inside_or_outside', last_time_moved='$lasttime', battery_status='$battery_status',last_time_inside='$lastinside', onoff='$onoff', last_changed='$last_changed' WHERE id=4";
   // $lasttime=$last_time_moved;
}


 if ($conn->query($sql) === TRUE) {
  echo "Data updated successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}
}
} 
else {
echo "No data received";
}

// Close connection
$conn->close();

?>


