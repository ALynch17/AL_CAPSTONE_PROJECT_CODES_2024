<?php
//include 'process.php';
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "capdatabase";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
//$conn = mysqli_connect("localhost", "root", "", "capdatabase");

// SQL query to fetch data from 'cattle' table
$sql = "SELECT * FROM cattle";
$rows = $conn->query($sql);
//$rows = mysqli_query($conn, "SELECT * FROM tb_data");
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Active Cattle Detection and Counting System</title>
    <link rel="stylesheet" href="css/web.css">
    <link rel="stylesheet" href="system.css">
</head>
<body>
    <h1 class="h1">
        CATTLE INFORMATION
   </h1>
        <div class="obj">
            
            <nav class="object">

          <table border = 1 cellpadding = 10>
              <tr>
                <th><u>ID</u></th>
                <th><u>Latitude</u></th>
                <th><u>Longitude</u></th>
                <th><u>Battery Status(%)</u></th>
                <th><u>Movement State</u></th>
                <th><u>Last Time Moved</u></th>
                <th><u>INSIDE/OUTSIDE THE FARM?</u></th>
                <th><u>Last Time Inside</u></th>
                <th><u>AUTHORIZED?</u></th>
                <th><u>ONLINE?</u></th>
                <th><u>Last Time Online</u></th>

              </tr>
              <?php $i = 1; ?>
              <?php foreach($rows as $ro) : ?>
                <tr>
                 
                  <td><?php echo $ro["id"]; ?></td>
                  <td><?php echo $ro["latitude"]; ?></td>
                  <td><?php echo $ro["longitude"]; ?></td>
                  <td><?php echo $ro["battery_status"]; ?></td>
                  <td><?php echo $ro["mstate"]; ?></td>
                  <td><?php echo $ro["last_time_moved"]; ?></td>
                  <td> <?php echo $ro["inside_or_outside"]; ?></td>  
                  <td><?php echo $ro["last_time_inside"]; ?></td>
                  <td><?php echo $ro["AUTHORIZED"]; ?></td>
                  <td><?php echo $ro["onoff"]; ?></td>
                  <td><?php echo $ro["last_changed"]; ?></td>
                </tr>
                <?php endforeach; ?>
          </table>
            </nav>
      </div>    
    
   
</body>
</html>