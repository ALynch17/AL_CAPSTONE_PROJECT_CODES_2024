<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Email Alert Control</title>
    <link rel="stylesheet" href="css/web.css">
    <link rel="stylesheet" href="authorize.css">
</head>
<body>
<h1>Cow Authorization</h1>
    <form action="process.php" method="post">
        <button type="submit" name="authorize" value="1">Authorize Cow</button>
        <button type="submit" name="authorize" value="0">Unauthorize Cow</button>
    </form>
</body>
</html>
