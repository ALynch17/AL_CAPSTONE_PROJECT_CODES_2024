<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Include PHPMailer files and any necessary configurations
require 'phpmailer/src/Exception.php';
    require 'phpmailer/src/PHPMailer.php';
    require 'phpmailer/src/SMTP.php';

// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$database = "capdatabase";


// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to check power status and movement status from 'info' table
$sql = "SELECT *, users.firstname, users.lastname, users.email 
        FROM info 
        INNER JOIN users ON info.users_id = users.id";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        // Extract data from the row
        $firstName = $row['firstname'];
        $lastName = $row['lastname'];
        $email = $row['email'];
        $deviceName = $row['device_name'];
        $deviceId = $row['device_id'];
        $powerStatus = $row['power_status'];
        $movementStatus = $row['movement_status'];

        // Send email alert if power status is false
        if ($powerStatus == False) {
            
            sendPowerAlert($email, $firstName, $lastName, $deviceName, $deviceId, $powerStatus, $movementStatus);
            Sleep(30000);
        }

        // Send email alert if movement status is true
        if ($movementStatus == True) {
            sendMovementAlert($email, $firstName, $lastName, $deviceName, $deviceId, $powerStatus, $movementStatus);
            Sleep(30000);
        }
    }
} else {
    echo "No data found in 'info' table.";
}

// Function to send power status alert using PHPMailer
function sendPowerAlert($email, $firstName, $lastName, $deviceName, $deviceId, $powerStatus, $movementStatus) {
    try {
    sendEmailAlert($email, "Power Status Alert - Device ID: $deviceId", 
        "Hello $firstName $lastName,<br><br>The power status of device $deviceName (ID: $deviceId) is false.<br><br>Power Status: $powerStatus<br>Movement Status: $movementStatus");
        echo "Power alert sent successfully to $email.<br>";
    } catch (Exception $e) {
        echo "Error sending power alert: {$e->getMessage()}";

        }   
     }

// Function to send movement status alert using PHPMailer
function sendMovementAlert($email, $firstName, $lastName, $deviceName, $deviceId, $powerStatus, $movementStatus) {
    sendEmailAlert($email, "Movement Status Alert - Device ID: $deviceId", 
        "Hello $firstName $lastName,<br><br>Movement has been detected on device $deviceName (ID: $deviceId).<br><br>Power Status: $powerStatus<br>Movement Status: $movementStatus");
        echo "Movement alert sent successfully to $email.<br>";
    }

// Function to send email alert using PHPMailer
function sendEmailAlert($recipientEmail, $subject, $message) {
    // Initialize PHPMailer
    $mail = new PHPMailer(true); // True enables exceptions

    try {
        // SMTP settings and email content
        $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com'; // Your SMTP server
    $mail->SMTPAuth = true;
    $mail->Username = 'capstonemailer1@gmail.com';
    $mail->Password = 'uztwvczocuekaeko';
    $mail->SMTPSecure = 'ssl'; // Enable TLS encryption, 'ssl' also accepted
    $mail->Port = 465; // TCP port to connect to

    $mail->setFrom('capstonemailer1@gmail.com');
    //$mail->addAddress($to); // Recipient
        $mail->addAddress($recipientEmail);
        $mail->Subject = $subject;
        $mail->Body = $message;
        $mail->isHTML(true); // Set email format to HTML

        // Send email
        $mail->send();
        //echo "Email alert sent successfully to $recipientEmail.<br>";
    } catch (Exception $e) {
        echo "Error sending email alert to $recipientEmail: {$mail->ErrorInfo}<br>";
    }
}

// Close database connection
$conn->close();
?>