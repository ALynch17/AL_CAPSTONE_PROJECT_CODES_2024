<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Coordinate Form</title>  
<link rel="stylesheet" href="css/web.css">
    <link rel="stylesheet" href="entergps.css">
</head>
<body>
<h1 class="h1">
        ENTER FARM COORDINATES
   </h1>
<form action="process.php" method="POST">
    <label for="lat1">Latitude 1:</label>
    <input type="text" id="lat1" name="lat1" required>
    <label for="long1">Longitude 1:</label>
    <input type="text" id="long1" name="long1" required><br>

    <label for="lat2">Latitude 2:</label>
    <input type="text" id="lat2" name="lat2" required>
    <label for="long2">Longitude 2:</label>
    <input type="text" id="long2" name="long2" required><br>

    <label for="lat3">Latitude 3:</label>
    <input type="text" id="lat3" name="lat3" required>
    <label for="long3">Longitude 3:</label>
    <input type="text" id="long3" name="long3" required><br>

    <label for="lat4">Latitude 4:</label>
    <input type="text" id="lat4" name="lat4" required>
    <label for="long4">Longitude 4:</label>
    <input type="text" id="long4" name="long4" required><br>
    
    <input  type="submit" value="Submit"> 

</form>

</body>
</html>
