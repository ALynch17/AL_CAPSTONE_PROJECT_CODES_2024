<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Active Cattle Detection and Counting System</title>
    <link rel="stylesheet" href="css/web.css">
    <link rel="stylesheet" href="css/obj.css">
</head>
<body>
    <h1 class="h1">
        OBJECTIVES
   </h1>
        <div class="obj">
            
            <nav class="object">
                <ol>
                    <li>Design and develop an electronic tag that identifies a specific head of cattle and can indicate
                        that the animal has moved. This electronic tag (e-tag) should communicate with a central
                        monitoring system (CMS) to allow real-time monitoring of the animal and the state of the tag.</li>
                        <br>
                        <li>The farm should be designed with an electronic system that detects when the e-tag is on or off
                            the farm. For the project design, the size and shape of the farm should be that of a standard
                            football field. However, a scaled-down farm can be used for demonstrating the project.</li>
                            <br>
                            <li>Design and develop a central monitoring system (CMS) that communicates with the cattle's
                                electronic tags (e-tag). The CMS should have a web page showing the number of cattle, a list of
                                cattle ID#, last time they moved and the battery status on the e-tag. The CMS should save all
                                historical data in a database. The user should be able to query the historical data.</li>
                                <br>
                                <li>The CMS should trigger an alert (send an email) for the following activities:<br>
                                    i. An e-tag is not detectable (an animal is missing or the e-tag is offline).<br>
                                    ii. An e-tag if detected off the farm.<br>
                                    iii. If an animal has not moved in a certain time period (research this time period).<br>
                                    iv. If an e-tag battery falls below a minimum voltage threshold. Battery replacement is
                                    needed.<br>
                                    The CMS should not send an alert if cattle are authorised to leave the farm through the
                                    gate.</li>
                                    <br>
                                    <li>The CMS should use e-tag information to count cattle leaving and entering the farm.</li>
                    
                    
                </ol>
            </nav>
        </div>
   


       
    
   
</body>
</html>