<?php
// Database credentials
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "capdatabase";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the user_data table exists
$tableExistsQuery = "SHOW TABLES LIKE 'user_data'";
$tableExistsResult = $conn->query($tableExistsQuery);

if ($tableExistsResult->num_rows == 0) {
    // Table doesn't exist, create the table
    $createTableQuery = "CREATE TABLE user_data (
        id INT AUTO_INCREMENT PRIMARY KEY,
        latitude1 DOUBLE,
        longitude1 DOUBLE,
        latitude2 DOUBLE,
        longitude2 DOUBLE,
        latitude3 DOUBLE,
        longitude3 DOUBLE,
        latitude4 DOUBLE,
        longitude4 DOUBLE
    )";

    if ($conn->query($createTableQuery) === TRUE) {
        echo "Table created successfully. ";
    } else {
        echo "Error creating table: " . $conn->error;
    }
}
// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect and validate user inputs from the form
    $coordinates = array(); // Array to store coordinates

    for ($i = 1; $i <= 4; $i++) {
        // Check if the input values are doubles
        $latitude = filter_input(INPUT_POST, "latitude{$i}", FILTER_VALIDATE_FLOAT);
        $longitude = filter_input(INPUT_POST, "longitude{$i}", FILTER_VALIDATE_FLOAT);

        // If both values are valid doubles, add them to the coordinates array
        if ($latitude !== false && $longitude !== false) {
            $coordinates[] = array('latitude' => $latitude, 'longitude' => $longitude);
        } else {
            die("Invalid input detected.");
        }
    }

    // Prepare and execute SQL statement to overwrite data in the database
    $replaceQuery = "REPLACE INTO user_data 
                     (latitude1, longitude1, latitude2, longitude2, latitude3, longitude3, latitude4, longitude4) 
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($replaceQuery);

    // Bind parameters
    $stmt->bind_param("dddddddd",
        $coordinates[0]['latitude'], $coordinates[0]['longitude'],
        $coordinates[1]['latitude'], $coordinates[1]['longitude'],
        $coordinates[2]['latitude'], $coordinates[2]['longitude'],
        $coordinates[3]['latitude'], $coordinates[3]['longitude']
    );

    // Execute the statement
    if ($stmt->execute()) {
        echo "User data stored successfully. ";
    } else {
        echo "Error: " . $conn->error;
    }

    // Close statement
    $stmt->close();

    // Fetch cattle coordinates from the database
    $cattleQuery = "SELECT id,latitude, longitude FROM cattle";
    $cattleResult = $conn->query($cattleQuery);

    if ($cattleResult->num_rows > 0) {
        // Loop through each cattle coordinate
        while ($cattleRow = $cattleResult->fetch_assoc()) {
            $id=$cattleRow['id'];
            $cattleCoordinate = array('latitude' => $cattleRow['latitude'], 'longitude' => $cattleRow['longitude']);
            $insideQuadrilateral = isPointInsidePolygon($coordinates, $cattleCoordinate);

            // Print result for each cattle coordinate
            if ($insideQuadrilateral) {
                echo "Cattle $id with coordinates ({$cattleCoordinate['latitude']}, {$cattleCoordinate['longitude']}) are inside the farm.<br>";
            } else {
                echo "Cattle $id with coordinates ({$cattleCoordinate['latitude']}, {$cattleCoordinate['longitude']}) are outside the farm.<br>";
            }
        }
    } else {
        echo "No cattle coordinates found in the database.";
    }
}

// Close the database connection
$conn->close();

// Function to check if a point is inside a quadrilateral
function isPointInsidePolygon($userDataCoordinates, $cattleCoordinate) {
    $minLatitude = min($userDataCoordinates[0]['latitude'], $userDataCoordinates[1]['latitude'], $userDataCoordinates[2]['latitude'], $userDataCoordinates[3]['latitude']);
    $maxLatitude = max($userDataCoordinates[0]['latitude'], $userDataCoordinates[1]['latitude'], $userDataCoordinates[2]['latitude'], $userDataCoordinates[3]['latitude']);
    $minLongitude = min($userDataCoordinates[0]['longitude'], $userDataCoordinates[1]['longitude'], $userDataCoordinates[2]['longitude'], $userDataCoordinates[3]['longitude']);
    $maxLongitude = max($userDataCoordinates[0]['longitude'], $userDataCoordinates[1]['longitude'], $userDataCoordinates[2]['longitude'], $userDataCoordinates[3]['longitude']);

    $cattleLatitude = $cattleCoordinate['latitude'];
    $cattleLongitude = $cattleCoordinate['longitude'];

    if ($cattleLatitude > $minLatitude && $cattleLatitude < $maxLatitude &&
        $cattleLongitude > $minLongitude && $cattleLongitude < $maxLongitude) {
        return true; // Inside the quadrilateral
    } else {
        return false; // Outside the quadrilateral
    }
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GPS coordinates</title>
</head>
<body>
    <h1>GPS COORDINATES</h1>
    <form method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
        <?php for ($i = 1; $i <= 4; $i++) : ?>
            <label for="latitude<?php echo $i ?>">Coordinate <?php echo $i ?> (Latitude Value 1):</label>
            <input type="text" name="latitude<?php echo $i ?>" id="latitude<?php echo $i ?>"><br>

            <label for="longitude<?php echo $i ?>">Coordinate <?php echo $i ?> (Longitude Value 2):</label>
            <input type="text" name="longitude<?php echo $i ?>" id="longitude<?php echo $i ?>"><br><br>
        <?php endfor; ?>

        <input type="submit" value="Submit">
    </form>
</body>
</html>
