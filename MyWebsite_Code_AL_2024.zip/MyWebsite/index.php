<?php
require_once 'includes/config.php';
require_once 'includes/login_view.inc.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Active Cattle Detection and Counting System</title>
    <link rel="stylesheet" href="css/reset.css">
    <link rel="stylesheet" href="css/index.css"> 
</head>
<body>


    

<?php
 if (!isset($_SESSION["user_id"])){?>
    <h2>LOGIN</h2>
    <form action="includes/login.inc.php" method="post">
    <h3>USERNAME</h3>
        <input type="text" name="username" placeholder="Username">
        <?php echo '<br>' ?>
        <h3>PASSWORD</h3>
        <input type="password" name="pword" placeholder="Password">
        <button>LOGIN</button>
</form>


<?php } ?>

<label>
<?php 
check_login_errors();
?>
</label> 


</body>
</html>