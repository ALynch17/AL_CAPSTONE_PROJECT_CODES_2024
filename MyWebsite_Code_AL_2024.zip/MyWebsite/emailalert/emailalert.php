<?php 
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$dsn = "mysql:host=localhost;dbname=capdatabase";
$dbusername="root";
$dbpassword="";

try {
    //code...
    $pdo = new PDO($dsn,$dbusername,$dbpassword );
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    //throw $th;
    echo "Connection failed: " . $e->getMessage();
}

try {
    //code...
//require_once "includes/dbh.inc.php";
require_once 'includes/login.inc.php';
require 'phpmailer/src/Exception.php';
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';

$query="SELECT * FROM cattle;";
$stmt = $pdo->prepare($query);
//$stmt->bindParam(":username",$username);

$stmt->execute();
$count=$stmt->rowCount();
//$x = 0;
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);

if ($count>0){
   foreach($results as $row){
     if (($row["battery_status"]<20) OR ($row["mstate"]!=1) OR ($row["inside_or_outside"]=="OUTSIDE")){
          $query="SELECT * FROM users WHERE username=$username AND pword=$pword;";
          $stmt = $pdo->prepare($query);


        $stmt->execute();

        $answer = $stmt->fetchAll(PDO::FETCH_ASSOC);
        if($answer){
           // while($row = $answer -> fetch_assoc()){
             //   $username=$row['username'];
               // $pword=$row['pword'];
                $email=$row['email'];
                $id=$row['id'];

                $mail = new PHPMailer (true);

                $mail -> isSMTP();
                $mail -> Host = 'smtp.gmail.com';
                $mail -> SMTPAuth = true;
                $mail -> Username = 'capstonemailer1@gmail.com';
                $mail -> Password = 'uztwvczocuekaeko';
                $mail -> SMTPSecure = 'ssl';
                $mail -> Port = 465;

                $mail -> setFrom('capstonemailer1@gmail.com');

                $mail-> addAddress($email);

                $mail-> isHTML(true);

                $mail -> Subject = "ALERT: Cattle #$id Battery State ! ";
                $mail -> Body = "Cattle #$id has low battery, specifically $battery_state%. Please change battery!";

                $mail -> send();
            }

     }
  

   // }
    //echo "id: " . htmlspecialchars($row["id"]). " -Battery Status: " . htmlspecialchars($row["battery_status"]). "%" . " E-Tag State: ". htmlspecialchars($row["state"]). " Last Time Moved: ". htmlspecialchars($row["last_time_moved"]) . "<br>";
   // echo "<tr>";
  //  echo "<td>" . htmlspecialchars($row["id"]) . "</td>";
   // echo "<td>" . htmlspecialchars($row["battery_status"]) . "</td>";
   // echo "<td>" . htmlspecialchars($row["state"]) . "</td>";
  //  echo "<td>" . htmlspecialchars($row["last_time_moved"]) . "</td>";
   // echo "</tr>";
    //echo "<td>" . "<br>" . "</td>";

   }
   
}
else{
    echo "There are no entries in the table";
}

   
$pdo=null;
$stmt=null;
                                    
} catch (PDOException $e) {
       //throw $th;
       die("Query failed: " . $e->getMessage());
        }

?>