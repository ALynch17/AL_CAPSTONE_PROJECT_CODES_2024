<?php
require_once 'includes/config.php';
require_once 'includes/login_view.inc.php';
//require 'RealTimeDataDisplay/testemail.php'; 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Active Cattle Detection and Counting System</title>
    <link rel="stylesheet" href="css/carousel-p.css">
    <link rel="stylesheet" href="css/reset.css">
    <link rel="stylesheet" href="css/web.css?v=<?php echo time();?>">
    
</head>
<body>
    
    <h1 class="h1main">
        <div class="h1maindiv">
          <img src="cattle.png" alt="cattle img">
            <nav class="h1mainnav">
                <ul>
                    <li><a href="background.php">BACKGROUND</a></li>
                    <li><a href="obj.php">OBJECTIVES</a></li>
                    <li><a href="cattlecount.php">NUMBER OF CATTLE</a></li>
                    <li><a href="RealTimeDataDisplay/entergps.php">FARM COORDINATES</a></li>
                    <li><a href="RealTimeDataDisplay/check.php">CATTLE INFO</a></li>
                    <li><a href="RealTimeDataDisplay/authorize.php">AUTHORIZATION?</a></li>
            
                    <li><form action="includes/logout.inc.php" method="post">
                    <button>LOGOUT</button>
                    </form></li>
                    <li><div>
                      
                    <?php 
                        output_username();
                        ?>                      

                    </div></li>
                </ul>
            </nav>
        </div>
        <div class="h1mainlogo">
        <a target="_blank" href="https://www.mona.uwi.edu"><div class="h1mainuwilogo"></div></a>
    </div>
       
    </h1>
    <div class="slideshow-container">

        <div class="mySlides fade">
          <div class="numbertext">1 / 3</div>
          <img src="slideshowImg4.jpg" class="slideshowImg"> 
        </div>
        
        <div class="mySlides fade">
          <div class="numbertext">2 / 3</div>
          <img src="slideshowImg2.jpg" class="slideshowImg2">
        </div>
        
        <div class="mySlides fade">
          <div class="numbertext">3 / 3</div>
          <img src="slideshowImg3.jpeg" class="slideshowImg3">
        </div>
        
        <a class="prev" onclick="plusSlides(-1)"></a>
        <a class="next" onclick="plusSlides(1)"></a>
        <div class="dotClass" style="text-align:center">
            <span class="dot" onclick="currentSlide(1)"></span> 
            <span class="dot" onclick="currentSlide(2)"></span> 
            <span class="dot" onclick="currentSlide(3)"></span> 
        </div>
    </div>
    <br>
    <script src="carousel.js"></script> 
     
    
</body>
</html>