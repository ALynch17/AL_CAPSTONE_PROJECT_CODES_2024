<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Active Cattle Detection and Counting System</title>
    <link rel="stylesheet" href="css/web.css">
    <link rel="stylesheet" href="css/cattleinfo.css">
</head>
<body>
    <h1 class="h1">
        CATTLE INFORMATION
   </h1>
        <div class="obj">
            
            <nav class="object">
                <table>
                <tr>
                <th><u>ID</u></th>
                <th><u>BATTERY STATUS(%)</u></th>
                <th><u>E-TAG STATE</u></th>
               <!-- <th><u>LAST TIME MOVED</u></th>-->
                <th><u>LATITUDE</u></th>
                <th><u>LONGITUDE</u></th>
                </tr>
                <?php
                            //unction get_count(object $pdo){
                                try {
                                    //code...
                                    require_once "includes/dbh.inc.php";
                                    $query="SELECT * FROM cattle;";
                                    $stmt = $pdo->prepare($query);
                                    //$stmt->bindParam(":username",$username);
   
                                    $stmt->execute();
                                    $count=$stmt->rowCount();
                                    //$x = 0;
                                    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
                                    
                                    if ($count>0){
                                       foreach($results as $row){
                                      // $x++;
                                      //  if ($x>0){
                                       //     echo '<br>';
                                       // }
                                        //echo "id: " . htmlspecialchars($row["id"]). " -Battery Status: " . htmlspecialchars($row["battery_status"]). "%" . " E-Tag State: ". htmlspecialchars($row["state"]). " Last Time Moved: ". htmlspecialchars($row["last_time_moved"]) . "<br>";
                                        echo "<tr>";
                                        echo "<td>" . htmlspecialchars($row["id"]) . "</td>";
                                        echo "<td>" . htmlspecialchars($row["battery_status"]) . "</td>";
                                        echo "<td>" . htmlspecialchars($row["mstate"]) . "</td>";
                                      //  echo "<td>" . htmlspecialchars($row["last_time_moved"]) . "</td>";
                                        echo "<td>" . htmlspecialchars($row["latitude"]) . "</td>";
                                        echo "<td>" . htmlspecialchars($row["longitude"]) . "</td>";
                                        echo "</tr>";
                                        //echo "<td>" . "<br>" . "</td>";

                                       }
                                       
                                    }
                                    else{
                                        echo "There are no entries in the table";
                                    }
                                  
                                   
                                    // include('C::/xampp/htdocs/MyWebsite/emailalert/emailalert.php');
                                    // include('emailalert.php');
                                     //require_once('emailalert/emailalert.php');

                                    $pdo=null;
                                    $stmt=null;

                                   
                                    
                                } catch (PDOException $e) {
                                    //throw $th;
                                    die("Query failed: " . $e->getMessage());
                                }
                                

                            
                               // }
                    ?>


                            </table>
            </nav>
        </div>
   


       
    
   
</body>
</html>